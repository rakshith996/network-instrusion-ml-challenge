"""
Network Intrusion Detection ML Challenge - solution
Usage:  python solution.py --data_dir <folder with train.csv, test.csv, sample_submission.csv>
Outputs (in --out_dir): submission.csv, cv_results.csv, confusion_matrix.png/.csv, feature_importance.csv

Design goals: robustness to distribution shift (test behaviour profiles are
separated from train), so model selection uses GROUPED cross-validation.
"""
import argparse
import os
import re
import warnings

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, f1_score
from sklearn.model_selection import GroupKFold, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.utils.class_weight import compute_sample_weight

warnings.filterwarnings("ignore")
SEED = 42
np.random.seed(SEED)


# --------------------------------------------------------------------------- #
# 1. Loading and schema detection (no column names are hard-coded)
# --------------------------------------------------------------------------- #
def load(data_dir):
    train = pd.read_csv(os.path.join(data_dir, "train.csv"))
    test = pd.read_csv(os.path.join(data_dir, "test.csv"))
    sub = pd.read_csv(os.path.join(data_dir, "sample_submission.csv"))
    return train, test, sub


def detect_schema(train, test, sub):
    # target = the column in train that is missing from test
    target_candidates = [c for c in train.columns if c not in test.columns]
    # prediction column in submission = the column that is not in test, or the last one
    pred_col = [c for c in sub.columns if c in target_candidates]
    pred_col = pred_col[0] if pred_col else sub.columns[-1]
    target = pred_col if pred_col in train.columns else target_candidates[0]
    id_col = [c for c in sub.columns if c != pred_col][0]
    return target, id_col, pred_col


# --------------------------------------------------------------------------- #
# 2. Cleaning + feature engineering
# --------------------------------------------------------------------------- #
def clean_and_engineer(train, test, target, id_col):
    X = train.drop(columns=[target]).copy()
    T = test.copy()
    test_ids = T[id_col].copy() if id_col in T.columns else pd.Series(np.arange(len(T)))

    # drop id column(s)
    drop = [c for c in X.columns if c == id_col or re.fullmatch(r"(?i)(row_?)?(id|index|unnamed.*)", c)]
    # drop columns that are (near) unique strings -> identifiers (IPs, MACs, flow ids...), can't generalise
    for c in X.columns:
        if X[c].dtype == object and X[c].nunique() > 0.5 * len(X):
            drop.append(c)
    # drop constants
    for c in X.columns:
        if X[c].nunique(dropna=False) <= 1:
            drop.append(c)
    # drop exact duplicate columns
    seen = {}
    for c in X.columns:
        key = pd.util.hash_pandas_object(X[c], index=False).sum()
        if key in seen and X[c].equals(X[seen[key]]):
            drop.append(c)
        else:
            seen[key] = c
    drop = sorted(set(drop))
    X = X.drop(columns=drop, errors="ignore")
    T = T.drop(columns=[c for c in drop if c in T.columns], errors="ignore")
    T = T.reindex(columns=X.columns)

    # name-based ratio / rate features (rates transfer better across behaviour profiles than raw volumes)
    num = X.select_dtypes(include=np.number).columns.tolist()

    def find(*keys):
        for c in num:
            if any(k in c.lower() for k in keys):
                return c
        return None

    byt, pkt, dur = find("byte", "size", "len"), find("pkt", "packet"), find("dur", "time")
    new = {}
    if byt and pkt:
        new["bytes_per_pkt"] = (byt, pkt)
    if pkt and dur:
        new["pkts_per_sec"] = (pkt, dur)
    if byt and dur:
        new["bytes_per_sec"] = (byt, dur)
    for name, (a, b) in new.items():
        for df in (X, T):
            df[name] = df[a] / (df[b].abs() + 1e-6)

    # log1p for heavily skewed non-negative numeric columns (helps linear models, harmless for trees)
    num = X.select_dtypes(include=np.number).columns.tolist()
    skewed = [c for c in num if X[c].min() >= 0 and X[c].skew() > 3]
    for c in skewed:
        X[c] = np.log1p(X[c])
        T[c] = np.log1p(T[c].clip(lower=0))

    X = X.replace([np.inf, -np.inf], np.nan)
    T = T.replace([np.inf, -np.inf], np.nan)
    info = dict(dropped=drop, engineered=list(new), log_transformed=skewed)
    return X, T, test_ids, info


def make_preprocessor(X, scale):
    num = X.select_dtypes(include=np.number).columns.tolist()
    cat = [c for c in X.columns if c not in num]
    num_steps = [("imp", SimpleImputer(strategy="median"))]
    if scale:
        num_steps.append(("sc", StandardScaler()))
    tf = [("num", Pipeline(num_steps), num)]
    if cat:
        tf.append(("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                                    ("oh", OneHotEncoder(handle_unknown="ignore", min_frequency=0.01,
                                                         sparse_output=False))]), cat))
    return ColumnTransformer(tf)


# --------------------------------------------------------------------------- #
# 3. Validation that mimics the train->test shift
# --------------------------------------------------------------------------- #
def make_groups(X, n_clusters=8):
    """Cluster rows in feature space; whole clusters are held out together,
    so each validation fold contains 'behaviour profiles' unseen in training."""
    num = X.select_dtypes(include=np.number)
    Z = StandardScaler().fit_transform(SimpleImputer(strategy="median").fit_transform(num))
    return KMeans(n_clusters=n_clusters, n_init=10, random_state=SEED).fit_predict(Z)


def get_models(X):
    return {
        "logreg": Pipeline([("prep", make_preprocessor(X, True)),
                            ("clf", LogisticRegression(max_iter=2000, C=0.5, class_weight="balanced"))]),
        "random_forest": Pipeline([("prep", make_preprocessor(X, False)),
                                   ("clf", RandomForestClassifier(n_estimators=400, min_samples_leaf=5,
                                                                  max_features="sqrt", class_weight="balanced_subsample",
                                                                  n_jobs=-1, random_state=SEED))]),
        "extra_trees": Pipeline([("prep", make_preprocessor(X, False)),
                                 ("clf", ExtraTreesClassifier(n_estimators=400, min_samples_leaf=5,
                                                              class_weight="balanced", n_jobs=-1, random_state=SEED))]),
        "hist_gb": Pipeline([("prep", make_preprocessor(X, False)),
                             ("clf", HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05, max_iter=300,
                                                                    min_samples_leaf=40, l2_regularization=1.0,
                                                                    random_state=SEED))]),
    }


def fit_model(model, X, y):
    if isinstance(model.steps[-1][1], HistGradientBoostingClassifier):
        model.fit(X, y, clf__sample_weight=compute_sample_weight("balanced", y))
    else:
        model.fit(X, y)
    return model


def cross_validate(models, X, y, groups, n_splits=5):
    rows, oof_store = [], {}
    schemes = {"random_stratified": StratifiedKFold(n_splits, shuffle=True, random_state=SEED).split(X, y),
               "grouped": GroupKFold(n_splits).split(X, y, groups)}
    for scheme, splits in schemes.items():
        splits = list(splits)
        for name, proto in models.items():
            from sklearn.base import clone
            oof = np.zeros(len(y), dtype=int)
            scores = []
            for tr, va in splits:
                m = fit_model(clone(proto), X.iloc[tr], y[tr])
                oof[va] = m.predict(X.iloc[va])
                scores.append(f1_score(y[va], oof[va], average="macro"))
            rows.append(dict(scheme=scheme, model=name, macro_f1_mean=np.mean(scores), macro_f1_std=np.std(scores)))
            oof_store[(scheme, name)] = oof
            print(f"[{scheme:18s}] {name:14s} macro-F1 = {np.mean(scores):.4f} +/- {np.std(scores):.4f}")
    return pd.DataFrame(rows), oof_store


# --------------------------------------------------------------------------- #
# 4. Main
# --------------------------------------------------------------------------- #
def main(data_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    train, test, sub = load(data_dir)
    target, id_col, pred_col = detect_schema(train, test, sub)
    print(f"target={target}  id={id_col}  pred_col={pred_col}")
    print("class distribution:\n", train[target].value_counts(normalize=True).round(3))

    train = train.drop_duplicates().reset_index(drop=True)
    le = LabelEncoder()
    y = le.fit_transform(train[target])
    X, T, test_ids, info = clean_and_engineer(train, test, target, id_col)
    print("preprocessing summary:", info)

    groups = make_groups(X)
    models = get_models(X)
    res, oof = cross_validate(models, X, y, groups)
    res.to_csv(os.path.join(out_dir, "cv_results.csv"), index=False)

    # pick the model with the best GROUPED cv score (robustness criterion)
    g = res[res.scheme == "grouped"].sort_values("macro_f1_mean", ascending=False)
    best = g.iloc[0]["model"]
    print(f"\nselected model (best grouped CV): {best}")

    # error analysis on grouped OOF predictions
    cm = confusion_matrix(y, oof[("grouped", best)])
    pd.DataFrame(cm, index=le.classes_, columns=le.classes_).to_csv(os.path.join(out_dir, "confusion_matrix.csv"))
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(5, 4))
        ax.imshow(cm, cmap="Blues")
        ax.set_xticks(range(len(le.classes_)), le.classes_, rotation=45, ha="right")
        ax.set_yticks(range(len(le.classes_)), le.classes_)
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, cm[i, j], ha="center", va="center")
        ax.set_xlabel("predicted"); ax.set_ylabel("true"); ax.set_title(f"Grouped-CV confusion ({best})")
        fig.tight_layout(); fig.savefig(os.path.join(out_dir, "confusion_matrix.png"), dpi=130)
    except Exception as e:
        print("plot skipped:", e)

    # final fit on all training data + permutation importance (sanity check on what drives predictions)
    final = fit_model(get_models(X)[best], X, y)
    try:
        pi = permutation_importance(final, X, y, n_repeats=3, random_state=SEED, scoring="f1_macro", n_jobs=-1)
        pd.DataFrame({"feature": X.columns, "importance": pi.importances_mean}) \
            .sort_values("importance", ascending=False).to_csv(os.path.join(out_dir, "feature_importance.csv"), index=False)
    except Exception as e:
        print("importance skipped:", e)

    preds = le.inverse_transform(final.predict(T))
    out = pd.DataFrame({id_col: test_ids.values, pred_col: preds})
    out = out[sub.columns]  # exact column order of sample_submission
    out.to_csv(os.path.join(out_dir, "submission.csv"), index=False)
    print("\nsaved submission.csv", out.shape, "\n", out[pred_col].value_counts(normalize=True).round(3))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default=".")
    ap.add_argument("--out_dir", default="outputs")
    a = ap.parse_args()
    main(a.data_dir, a.out_dir)
