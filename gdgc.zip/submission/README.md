# Network Intrusion Detection ML Challenge: GDG on Campus AI/ML Recruitment


## 1. Problem understanding
Multiclass classification of network flows into **Benign, Availability, Reconnaissance, Spoofing**
from numerical + categorical traffic-flow features. The key statement in the brief is that the
evaluation data contains *behaviour profiles deliberately separated from training data*.
So this is a **distribution-shift / generalisation** problem, not a plain tabular classification task.
Ordinary random cross-validation would leak near-identical flows between train and validation folds
and give optimistic scores that do not carry over to the leaderboard.

## 2. Approach in one paragraph
Clean the data and remove identifier-like columns, add rate/ratio features, build a **grouped
cross-validation** that holds out whole clusters of similar flows (simulating unseen behaviour
profiles), compare four regularised models with **macro-F1**, pick the model that is best under
*grouped* CV (not random CV), refit on all training data and predict the test set.

## 3. Pipeline and reasoning

| Step | What I did | Why |
|---|---|---|
| Schema detection | Target = column in train missing from test; ID + prediction column read from `sample_submission.csv` | Guarantees the submission format matches exactly |
| Cleaning | Dropped exact duplicate rows, constant columns, duplicate columns, ID columns, and near-unique string columns (e.g. IP/flow-id style) | Identifiers let a model memorise specific hosts/sessions; they cannot generalise to unseen profiles |
| Missing / inf values | Median imputation (numeric), most-frequent (categorical); inf -> NaN | Robust to outliers; done inside the pipeline so no leakage from validation folds |
| Categorical encoding | One-hot with `handle_unknown="ignore"` and `min_frequency=0.01` | Unseen/rare categories in the shifted test set will not crash or dominate the model |
| Skew handling | `log1p` on non-negative columns with skew > 3 | Byte/packet counts are heavy-tailed; helps linear models and reduces outlier influence |
| Feature engineering | bytes/packet, packets/sec, bytes/sec (when matching columns exist) | Rates describe *behaviour* and transfer better across profiles than raw volumes |
| Class imbalance | `class_weight="balanced"` (or balanced sample weights for gradient boosting) | Avoids ignoring minority classes; chosen over SMOTE because synthetic samples cannot create genuinely new behaviour profiles and add leakage risk inside CV |
| Validation | **KMeans (k=8) on scaled features -> `GroupKFold(5)`**, compared against random `StratifiedKFold(5)` | Held-out clusters mimic the unseen-profile test set; the gap between the two schemes measures how much shift matters |
| Metric | Macro-F1 | Treats all four classes equally, so minority classes count |
| Models | Logistic Regression (baseline), Random Forest, Extra Trees, HistGradientBoosting | Covers linear vs bagging vs boosting; all heavily regularised (`min_samples_leaf`, shallow depth, L2) because robustness matters more than peak score |
| Selection | Best **grouped-CV** macro-F1 | Selects for generalisation, not memorisation |
| Error analysis | Grouped out-of-fold confusion matrix + permutation importance | Shows which classes are confused and whether predictions rely on sensible features |

## 4. Results (fill in from `outputs/cv_results.csv` after running)

| Model | Random CV macro-F1 | Grouped CV macro-F1 |
|---|---|---|
| Logistic Regression | | |
| Random Forest | | |
| Extra Trees | | |
| HistGradientBoosting | | |

**Selected model:** <name> (best grouped CV).
**Observation:** <e.g. random CV was X points higher than grouped CV, confirming the distribution shift>.
**Error analysis:** <which classes are confused most, from `confusion_matrix.png`>.
**Top features:** <from `feature_importance.csv`, and whether they make domain sense>.

## 5. What I tried that did not help / limitations
<Fill in honestly, e.g. SMOTE, extra feature crosses, deeper trees, any model that scored high on random CV but dropped on grouped CV.>
Limitations: the grouping is an approximation of the real train/test split; k=8 clusters is a heuristic;
rate features are only created when matching column names exist.

## 6. Rules compliance
Only the provided competition data was used; no external labelled data; no attempt to obtain or
hand-label test labels. Random seed fixed (42) for reproducibility.

## 7. How to reproduce
```bash
pip install -r requirements.txt
python solution.py --data_dir <folder with train.csv, test.csv, sample_submission.csv> --out_dir outputs
```
Produces `outputs/submission.csv`, `cv_results.csv`, `confusion_matrix.csv/.png`, `feature_importance.csv`.
